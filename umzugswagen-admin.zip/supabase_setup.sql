-- Supabase-Einrichtung für "Umzugswagen Westerstede"
-- 1) Zuerst in Supabase unter Authentication -> Users deinen Admin-Benutzer
--    mit E-Mail + Passwort anlegen.
-- 2) Danach in SQL Editor dieses komplette Skript ausführen.
-- 3) In der letzten INSERT-Zeile DEINE E-MAIL einsetzen.

create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  event_date date not null,
  event_time time,
  location text,
  description text,
  created_at timestamptz not null default now()
);

create table if not exists public.gallery (
  id uuid primary key default gen_random_uuid(),
  file_path text not null unique,
  image_url text not null,
  caption text,
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.events enable row level security;
alter table public.gallery enable row level security;

drop policy if exists "admin can read own admin row" on public.admin_users;
create policy "admin can read own admin row"
on public.admin_users for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "public can read events" on public.events;
create policy "public can read events"
on public.events for select
to anon, authenticated
using (true);

drop policy if exists "admins can manage events" on public.events;
create policy "admins can manage events"
on public.events for all
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

drop policy if exists "public can read gallery" on public.gallery;
create policy "public can read gallery"
on public.gallery for select
to anon, authenticated
using (true);

drop policy if exists "admins can manage gallery" on public.gallery;
create policy "admins can manage gallery"
on public.gallery for all
to authenticated
using (exists (select 1 from public.admin_users a where a.user_id = auth.uid()))
with check (exists (select 1 from public.admin_users a where a.user_id = auth.uid()));

-- Öffentlicher Bilder-Speicher.
insert into storage.buckets (id, name, public)
values ('website-images', 'website-images', true)
on conflict (id) do update set public = true;

drop policy if exists "public can view website images" on storage.objects;
create policy "public can view website images"
on storage.objects for select
to public
using (bucket_id = 'website-images');

drop policy if exists "admins can upload website images" on storage.objects;
create policy "admins can upload website images"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'website-images'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

drop policy if exists "admins can update website images" on storage.objects;
create policy "admins can update website images"
on storage.objects for update
to authenticated
using (
  bucket_id = 'website-images'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
)
with check (
  bucket_id = 'website-images'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

drop policy if exists "admins can delete website images" on storage.objects;
create policy "admins can delete website images"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'website-images'
  and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
);

-- >>> HIER DEINE ADMIN-E-MAIL EINSETZEN <<<
-- Beispiel:
-- insert into public.admin_users (user_id)
-- select id from auth.users where email = 'deine@email.de'
-- on conflict (user_id) do nothing;

-- Sicherheitshinweis:
-- Niemals einen "service_role" oder Secret Key in admin.html eintragen.
-- Im Browser darf nur die Supabase-URL und der Publishable/Anon-Key verwendet werden.
