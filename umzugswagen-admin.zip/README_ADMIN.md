# Adminbereich – Umzugswagen Westerstede

## Einrichtung

1. In Supabase einen Benutzer unter **Authentication → Users** anlegen.
2. `supabase_setup.sql` im Supabase **SQL Editor** ausführen.
3. In der letzten INSERT-Abfrage deine Admin-E-Mail einsetzen und die Abfrage ausführen.
4. `admin.html` öffnen und `SUPABASE_URL` sowie `SUPABASE_PUBLISHABLE_KEY` eintragen.
5. `admin.html` nach GitHub hochladen.
6. Danach erreichst du den Bereich über:
   `https://wigbersmarein.github.io/umzugswagen-westerstede/admin.html`

**Wichtig:** Niemals einen Secret-/Service-Role-Key in `admin.html` verwenden.
